import{j as a}from"./index-Bg6wgV-_.js";function l({children:o,className:r=""}){return a.jsx("div",{className:"h-full overflow-y-auto ".concat(r),children:o})}export{l as S};
