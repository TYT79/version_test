import{aL as t,aM as o}from"./index-BR8Pmh83.js";const s=t()(o((a,e)=>({autoPage:!1,toggleAutoPage:()=>a({autoPage:!e().autoPage})}),{name:"reading-storage"}));export{s as u};
