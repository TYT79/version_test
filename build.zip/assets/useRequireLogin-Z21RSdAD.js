import{n,r as s}from"./index-Bg6wgV-_.js";function t(){const o=n(e=>e.isLogin),i=n(e=>e.openLoginDialog);return s.useEffect(()=>{o||i()},[o,i]),o}export{t as u};
