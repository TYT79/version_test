import{j as a}from"./index-BR8Pmh83.js";function l({children:o,className:r=""}){return a.jsx("div",{className:"h-full overflow-y-auto ".concat(r),children:o})}export{l as S};
