/* eslint-disable no-restricted-globals */
// 保證每次開啟網頁（含 iOS Web Clip 全螢幕模式）都拿到最新的 index.html，不被瀏覽器或 CDN 的
// HTTP 快取卡住舊版——參考自 18comic_react 專案的做法。比起指望託管平台支援 Cache-Control／
// _headers 這類慣例（測試過 Cloudflare 一般 CDN 模式不吃 _headers）更可靠，因為 Service Worker
// 是瀏覽器原生 API，換平台也不用重新確認有沒有支援。
//
// 只處理「網頁本身」（request.mode === 'navigate'，也就是每次打開/整理頁面時瀏覽器發的那個請求）：
// 一律直接打網路要最新版，不從快取拿，網路真的斷線就讓它照瀏覽器預設行為失敗。
// 其他資源（/assets/ 底下的 JS/CSS/圖片）不特別處理，交給瀏覽器預設快取行為就好——
// 這些檔名本來就帶 content hash，內容一變檔名就變，可以放心快取到天長地久，不需要 Service Worker 介入。
self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request));
  }
});
